#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "format.h"
#include "aes.h"
#include "test.h"
#include "global.h"


void run_crypto() {
    test_data_exchange();
}
