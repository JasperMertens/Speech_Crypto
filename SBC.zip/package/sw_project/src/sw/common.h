#ifndef _COMMON_H_
#define _COMMON_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "platform/platform.h"

#include "performance.h"

#include "xil_printf.h"
#include "xil_cache.h"

#endif
